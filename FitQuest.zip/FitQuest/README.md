# FitQuest – Android-Sportapp

Kotlin + Jetpack Compose, Room (lokale Datenbank), Health Connect für Garmin.

## Starten
1. Ordner in **Android Studio** (Ladybug oder neuer) öffnen. Studio legt den Gradle-Wrapper selbst an und synchronisiert das Projekt.
2. Gerät oder Emulator (Android 9+) wählen und **Run** drücken.
3. Für Health Connect: Android 14+ hat es eingebaut, sonst die App „Health Connect" aus dem Play Store installieren.

## Funktionen
| Bereich | Umsetzung |
|---|---|
| Workouts | 7 vorgefertigte Workouts, eigene per Builder (Reihenfolge, Sätze, Wdh., Gewicht), Kopieren, Löschen |
| Übungsbibliothek | 38 Übungen, nach Muskelgruppe und Trainingsmittel filterbar, eigene Übungen speichern, im Builder als Bausteine nutzbar |
| Kalender | Monatsansicht, Workouts planen, geloggte Einheiten mit Sätzen/Wdh./Gewicht/Anstrengung |
| Anpassung | Nach jeder Übung „Zu leicht / Passend / Zu hart" → Zielwerte fürs nächste Mal (`logic/Progression.kt`) |
| Kalorientracker | Tagesansicht, Kalorien + Eiweiss/Kohlenhydrate/Fett, Tagesziele einstellbar |
| Gamification | XP, Level, Wochenserie mit Wochenziel, 13 Abzeichen (`logic/Gamification.kt`) |
| Cardio | Manuelles Loggen (Hometrainer, Laufband usw.) mit Zeit, Distanz, Pace/km/h, kcal |
| Garmin | Import über Health Connect inkl. GPS-Route (als Linie gezeichnet) |

## Garmin einrichten
Garmin Connect App → Einstellungen → Health Connect → Verbindung aktivieren und Daten freigeben.
Danach in FitQuest: Training → Cardio → „Aus Health Connect".

## Bekannte Grenzen / nächste Schritte
- Die Route wird als Linie ohne Kartenhintergrund gezeichnet. Für echte Karten: Maps Compose (API-Key) oder osmdroid.
- Daten sind nur lokal gespeichert. Für Cloud-Sync ist `data/Repository.kt` die einzige Stelle, die erweitert werden muss.
- Die Version der Health-Connect-Bibliothek (`1.1.0-rc01`) ist in `app/build.gradle.kts` festgelegt; bei Build-Fehlern dort auf die aktuelle Version anheben.
- Kein App-Icon, keine Tests.
