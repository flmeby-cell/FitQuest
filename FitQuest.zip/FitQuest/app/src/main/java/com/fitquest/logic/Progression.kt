package com.fitquest.logic

import kotlin.math.max
import kotlin.math.roundToInt

enum class Effort(val label: String, val hint: String) {
    EASY("Zu leicht", "Nächstes Mal mehr"),
    OK("Passend", "Langsam steigern"),
    HARD("Zu hart", "Nächstes Mal etwas weniger"),
}

data class Target(val sets: Int, val reps: Int, val weightKg: Float)

/**
 * Passt die Zielwerte einer Übung nach dem Feedback an.
 *
 * - Mit Gewicht: zu leicht = mehr Gewicht, passend = erst Wiederholungen (bis 12), dann Gewicht,
 *   zu hart = rund 8 % weniger Gewicht.
 * - Körpergewicht: zu leicht = mehr Wiederholungen (ab 20 ein Satz mehr), passend = +1 wenn alles geschafft,
 *   zu hart = weniger Wiederholungen.
 * - Zeitübungen: Sekunden rauf oder runter.
 */
object Progression {
    private const val MAX_REPS_BEFORE_WEIGHT_UP = 12
    private const val RESET_REPS_AFTER_WEIGHT_UP = 8

    private fun roundToPlate(w: Float): Float = (w / 1.25f).roundToInt() * 1.25f

    private fun weightStep(w: Float): Float = max(2.5f, roundToPlate(w * 0.05f))

    fun next(t: Target, effort: Effort, allDone: Boolean, timed: Boolean): Target = when {
        timed -> when (effort) {
            Effort.EASY -> t.copy(reps = t.reps + 10)
            Effort.OK -> if (allDone) t.copy(reps = t.reps + 5) else t
            Effort.HARD -> t.copy(reps = (t.reps - 10).coerceAtLeast(10))
        }

        t.weightKg > 0f -> when (effort) {
            Effort.EASY -> t.copy(weightKg = roundToPlate(t.weightKg + weightStep(t.weightKg)))
            Effort.OK -> when {
                !allDone -> t
                t.reps < MAX_REPS_BEFORE_WEIGHT_UP -> t.copy(reps = t.reps + 1)
                else -> t.copy(
                    reps = RESET_REPS_AFTER_WEIGHT_UP,
                    weightKg = roundToPlate(t.weightKg + weightStep(t.weightKg)),
                )
            }

            Effort.HARD -> {
                var lowered = roundToPlate(t.weightKg * 0.92f)
                if (lowered >= t.weightKg) lowered = (t.weightKg - 1.25f).coerceAtLeast(0f)
                t.copy(weightKg = lowered)
            }
        }

        else -> when (effort) {
            Effort.EASY ->
                if (t.reps >= 20 && t.sets < 5) t.copy(sets = t.sets + 1, reps = 12)
                else t.copy(reps = t.reps + 2)

            Effort.OK -> if (allDone) t.copy(reps = (t.reps + 1).coerceAtMost(30)) else t
            Effort.HARD -> t.copy(reps = (t.reps - 2).coerceAtLeast(5))
        }
    }
}
