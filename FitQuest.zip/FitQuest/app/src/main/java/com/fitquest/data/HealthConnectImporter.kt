package com.fitquest.data

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseRouteResult
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import com.fitquest.logic.Gamification
import java.time.Instant
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Liest Cardio-Einheiten aus Health Connect. Garmin Connect schreibt dorthin, sobald in der
 * Garmin-Connect-App unter Einstellungen -> Health Connect aktiviert ist.
 */
class HealthConnectImporter(private val context: Context) {

    /** Ohne diese beiden Rechte ist kein Import möglich. */
    val basePermissions: Set<String> = setOf(
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
    )

    /** Inklusive Route (GPS-Strecke); wird beim Import optional genutzt. */
    val permissions: Set<String> = basePermissions + HealthPermission.PERMISSION_READ_EXERCISE_ROUTES

    enum class Availability { AVAILABLE, UPDATE_REQUIRED, UNAVAILABLE }

    fun availability(): Availability = when (HealthConnectClient.getSdkStatus(context)) {
        HealthConnectClient.SDK_AVAILABLE -> Availability.AVAILABLE
        HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> Availability.UPDATE_REQUIRED
        else -> Availability.UNAVAILABLE
    }

    private fun client(): HealthConnectClient = HealthConnectClient.getOrCreate(context)

    suspend fun hasBasePermissions(): Boolean =
        client().permissionController.getGrantedPermissions().containsAll(basePermissions)

    /** Liest die Einheiten der letzten [days] Tage. Kraft-Trainings werden übersprungen. */
    suspend fun readRecent(days: Long = 60): List<CardioLog> {
        val client = client()
        val granted = client.permissionController.getGrantedPermissions()
        val routeAllowed = HealthPermission.PERMISSION_READ_EXERCISE_ROUTES in granted

        val end = Instant.now()
        val start = end.minus(days, ChronoUnit.DAYS)
        val sessions = client.readRecords(
            ReadRecordsRequest(
                recordType = ExerciseSessionRecord::class,
                timeRangeFilter = TimeRangeFilter.between(start, end),
            ),
        ).records

        val zone = ZoneId.systemDefault()
        val result = mutableListOf<CardioLog>()
        for (s in sessions) {
            val type = typeName(s.exerciseType) ?: continue
            val durationSec = ChronoUnit.SECONDS.between(s.startTime, s.endTime).toInt()
            if (durationSec <= 0) continue

            val aggregate = client.aggregate(
                AggregateRequest(
                    metrics = setOf(DistanceRecord.DISTANCE_TOTAL, TotalCaloriesBurnedRecord.ENERGY_TOTAL),
                    timeRangeFilter = TimeRangeFilter.between(s.startTime, s.endTime),
                ),
            )
            val km = (aggregate[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0) / 1000.0
            val kcal = (aggregate[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories ?: 0.0).roundToInt()

            val route = if (routeAllowed) {
                (s.exerciseRouteResult as? ExerciseRouteResult.Data)?.let { encodeRoute(it) }
            } else null

            result += CardioLog(
                date = s.startTime.atZone(zone).toLocalDate().toEpochDay(),
                type = type,
                durationSec = durationSec,
                distanceKm = km,
                kcal = kcal,
                source = "Health Connect",
                externalId = s.metadata.id,
                route = route,
                xp = Gamification.cardioXp(durationSec, km),
            )
        }
        return result
    }

    private fun encodeRoute(data: ExerciseRouteResult.Data): String? {
        val points = data.exerciseRoute.route
        if (points.size < 2) return null
        val step = max(1, points.size / 300)
        return points.filterIndexed { i, _ -> i % step == 0 || i == points.lastIndex }
            .joinToString(";") { "%.5f,%.5f".format(java.util.Locale.US, it.latitude, it.longitude) }
    }

    /** null = nicht importieren (z. B. Krafttraining, das in FitQuest selbst geloggt wird). */
    private fun typeName(type: Int): String? = when (type) {
        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING,
        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL -> "Laufen"

        ExerciseSessionRecord.EXERCISE_TYPE_BIKING,
        ExerciseSessionRecord.EXERCISE_TYPE_BIKING_STATIONARY -> "Radfahren"

        ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "Gehen"
        ExerciseSessionRecord.EXERCISE_TYPE_HIKING -> "Wandern"

        ExerciseSessionRecord.EXERCISE_TYPE_ROWING,
        ExerciseSessionRecord.EXERCISE_TYPE_ROWING_MACHINE -> "Rudern"

        ExerciseSessionRecord.EXERCISE_TYPE_ELLIPTICAL -> "Crosstrainer"

        ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_POOL,
        ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_OPEN_WATER -> "Schwimmen"

        ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING,
        ExerciseSessionRecord.EXERCISE_TYPE_WEIGHTLIFTING -> null

        else -> "Sonstiges"
    }
}
