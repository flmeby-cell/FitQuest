package com.fitquest.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Datumsfelder sind immer LocalDate.toEpochDay(). */

@Entity(tableName = "exercises")
data class Exercise(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val muscleGroup: String,
    val equipment: String,
    /** true = Zeitübung (Plank etc.), "reps" bedeutet dann Sekunden */
    val timed: Boolean = false,
    val isCustom: Boolean = false,
)

@Entity(tableName = "workouts")
data class Workout(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val isPreset: Boolean = false,
    val description: String = "",
)

/** Eine Übung innerhalb eines Workouts inkl. aktueller Zielwerte (werden nach Feedback angepasst). */
@Entity(tableName = "workout_exercises", indices = [Index("workoutId")])
data class WorkoutExercise(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workoutId: Long,
    val exerciseId: Long,
    val position: Int,
    val sets: Int,
    val reps: Int,
    val weightKg: Float,
)

@Entity(tableName = "planned_workouts", indices = [Index("date")])
data class PlannedWorkout(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long,
    val workoutId: Long,
)

@Entity(tableName = "workout_logs", indices = [Index("date")])
data class WorkoutLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long,
    val workoutId: Long,
    val workoutName: String,
    val durationSec: Int,
    val xp: Int,
)

@Entity(tableName = "set_logs", indices = [Index("logId"), Index("date")])
data class SetLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val logId: Long,
    val date: Long,
    val exerciseId: Long,
    val exerciseName: String,
    val setIndex: Int,
    val reps: Int,
    val weightKg: Float,
    val timed: Boolean,
    /** Anstrengung der Übung (Effort.label) */
    val effort: String,
)

@Entity(
    tableName = "cardio_logs",
    indices = [Index("date"), Index(value = ["externalId"], unique = true)],
)
data class CardioLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long,
    val type: String,
    val durationSec: Int,
    val distanceKm: Double,
    val kcal: Int,
    /** "Manuell" oder "Health Connect" */
    val source: String,
    val externalId: String? = null,
    /** "lat,lon;lat,lon;..." (max. ca. 300 Punkte) */
    val route: String? = null,
    val xp: Int = 0,
)

@Entity(tableName = "food_entries", indices = [Index("date")])
data class FoodEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long,
    val name: String,
    val kcal: Int,
    val protein: Int = 0,
    val carbs: Int = 0,
    val fat: Int = 0,
)
