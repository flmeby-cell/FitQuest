package com.fitquest.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fitquest.data.FoodEntry

@Composable
fun HomeScreen(vm: AppViewModel, onStart: (Long) -> Unit, onOpenTraining: () -> Unit) {
    val stats by vm.stats.collectAsState()
    val planned by vm.planned.collectAsState()
    val workouts by vm.workouts.collectAsState()
    val logs by vm.workoutLogs.collectAsState()
    val cardio by vm.cardioLogs.collectAsState()
    val goals by vm.goals.collectAsState()
    val day = today()
    val food by remember(day) { vm.foodFor(day) }.collectAsState(emptyList<FoodEntry>())

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(fmtDay(day, "EEEE, d. MMMM"), style = MaterialTheme.typography.titleLarge)
        LevelCard(stats)

        Text("Heute geplant", style = MaterialTheme.typography.titleMedium)
        val todays = planned.filter { it.date == day }
        if (todays.isEmpty()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Kein Workout geplant.")
                    OutlinedButton(onClick = onOpenTraining) { Text("Workout wählen") }
                }
            }
        } else {
            todays.forEach { p ->
                val workout = workouts.firstOrNull { it.id == p.workoutId } ?: return@forEach
                val done = logs.any { it.date == day && it.workoutId == p.workoutId }
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(workout.name, style = MaterialTheme.typography.titleSmall)
                        if (done) Text("✓ Erledigt")
                        else Button(onClick = { onStart(workout.id) }) { Text("Start") }
                    }
                }
            }
        }

        Text("Kalorien heute", style = MaterialTheme.typography.titleMedium)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val eaten = food.sumOf { it.kcal }
                Text("$eaten / ${goals.kcal} kcal")
                LinearProgressIndicator(
                    progress = { (eaten / goals.kcal.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        val recent = (
            logs.map { it.date to "${it.workoutName} · +${it.xp} XP" } +
                cardio.map { it.date to "${it.type} · ${"%.1f".format(it.distanceKm)} km · +${it.xp} XP" }
            ).sortedByDescending { it.first }.take(3)
        if (recent.isNotEmpty()) {
            Text("Zuletzt", style = MaterialTheme.typography.titleMedium)
            recent.forEach { (d, text) ->
                Text("${fmtDay(d)}: $text", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
