package com.fitquest.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FitQuestTheme { FitQuestApp() } }
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Heute", Icons.Filled.Home),
    Tab("train", "Training", Icons.Filled.FitnessCenter),
    Tab("calendar", "Kalender", Icons.Filled.CalendarMonth),
    Tab("food", "Ernährung", Icons.Filled.Restaurant),
    Tab("progress", "Level", Icons.Filled.EmojiEvents),
)

@Composable
fun FitQuestApp(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBar = tabs.any { it.route == route }

    val startWorkout: (Long) -> Unit = { id -> nav.navigate("active/$id") }

    Scaffold(
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = {
                                nav.navigate(tab.route) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
            composable("home") {
                HomeScreen(vm, onStart = startWorkout, onOpenTraining = { nav.navigate("train") })
            }
            composable("train") {
                TrainScreen(
                    vm,
                    onStart = startWorkout,
                    onEdit = { id -> nav.navigate("builder/$id") },
                )
            }
            composable("calendar") { CalendarScreen(vm, onStart = startWorkout) }
            composable("food") { NutritionScreen(vm) }
            composable("progress") { ProgressScreen(vm) }
            composable(
                "builder/{id}",
                arguments = listOf(navArgument("id") { type = NavType.LongType }),
            ) { entry ->
                BuilderScreen(vm, entry.arguments?.getLong("id") ?: -1L, onDone = { nav.popBackStack() })
            }
            composable(
                "active/{id}",
                arguments = listOf(navArgument("id") { type = NavType.LongType }),
            ) { entry ->
                ActiveWorkoutScreen(vm, entry.arguments?.getLong("id") ?: -1L, onExit = { nav.popBackStack() })
            }
        }
    }
}
