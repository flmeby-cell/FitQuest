@file:OptIn(ExperimentalLayoutApi::class)

package com.fitquest.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

/**
 * Chip-Auswahl. Mit [allLabel] ist die Auswahl optional (null = "Alle"), ohne [allLabel] ist immer
 * genau ein Wert gewählt (für Formulare).
 */
@Composable
fun ChipRow(
    options: List<String>,
    selected: String?,
    onSelect: (String?) -> Unit,
    allLabel: String? = "Alle",
) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        if (allLabel != null) {
            FilterChip(selected = selected == null, onClick = { onSelect(null) }, label = { Text(allLabel) })
        }
        options.forEach { option ->
            FilterChip(
                selected = selected == option,
                onClick = {
                    onSelect(if (allLabel == null) option else if (selected == option) null else option)
                },
                label = { Text(option) },
            )
        }
    }
}
