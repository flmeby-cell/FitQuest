package com.fitquest.data

object Categories {
    val muscleGroups = listOf(
        "Brust", "Rücken", "Schultern", "Bizeps", "Trizeps",
        "Beine", "Gesäss", "Bauch/Core", "Ganzkörper",
    )
    val equipment = listOf(
        "Körpergewicht", "Kurzhantel", "Langhantel", "Kabelzug",
        "Maschine", "Kettlebell", "Widerstandsband",
    )
}

private data class SeedEx(val name: String, val muscle: String, val equip: String, val timed: Boolean = false)

/** (Übungsname, Sätze, Wiederholungen bzw. Sekunden, Gewicht kg) */
private data class SeedItem(val exercise: String, val sets: Int, val reps: Int, val kg: Float = 0f)

private data class SeedWorkout(val name: String, val description: String, val items: List<SeedItem>)

private val seedExercises = listOf(
    // Brust
    SeedEx("Bankdrücken", "Brust", "Langhantel"),
    SeedEx("Schrägbankdrücken", "Brust", "Kurzhantel"),
    SeedEx("Liegestütze", "Brust", "Körpergewicht"),
    SeedEx("Kabel-Fliegende", "Brust", "Kabelzug"),
    SeedEx("Brustpresse", "Brust", "Maschine"),
    // Rücken
    SeedEx("Klimmzüge", "Rücken", "Körpergewicht"),
    SeedEx("Rudern vorgebeugt", "Rücken", "Langhantel"),
    SeedEx("Einarmiges Rudern", "Rücken", "Kurzhantel"),
    SeedEx("Latzug", "Rücken", "Kabelzug"),
    SeedEx("Kreuzheben", "Rücken", "Langhantel"),
    SeedEx("Band-Rudern", "Rücken", "Widerstandsband"),
    // Schultern
    SeedEx("Schulterdrücken", "Schultern", "Kurzhantel"),
    SeedEx("Seitheben", "Schultern", "Kurzhantel"),
    SeedEx("Face Pulls", "Schultern", "Kabelzug"),
    SeedEx("Pike-Liegestütze", "Schultern", "Körpergewicht"),
    SeedEx("Band Pull-Apart", "Schultern", "Widerstandsband"),
    // Arme
    SeedEx("Bizepscurls", "Bizeps", "Kurzhantel"),
    SeedEx("Hammercurls", "Bizeps", "Kurzhantel"),
    SeedEx("Langhantelcurls", "Bizeps", "Langhantel"),
    SeedEx("Dips", "Trizeps", "Körpergewicht"),
    SeedEx("Trizepsdrücken", "Trizeps", "Kabelzug"),
    SeedEx("Stirndrücken", "Trizeps", "Langhantel"),
    // Beine
    SeedEx("Kniebeuge", "Beine", "Langhantel"),
    SeedEx("Goblet Squat", "Beine", "Kettlebell"),
    SeedEx("Ausfallschritte", "Beine", "Körpergewicht"),
    SeedEx("Beinpresse", "Beine", "Maschine"),
    SeedEx("Rumänisches Kreuzheben", "Beine", "Langhantel"),
    SeedEx("Wadenheben", "Beine", "Körpergewicht"),
    // Gesäss
    SeedEx("Hip Thrusts", "Gesäss", "Langhantel"),
    SeedEx("Glute Bridge", "Gesäss", "Körpergewicht"),
    SeedEx("Kettlebell Swings", "Gesäss", "Kettlebell"),
    // Core
    SeedEx("Plank", "Bauch/Core", "Körpergewicht", timed = true),
    SeedEx("Seitstütz", "Bauch/Core", "Körpergewicht", timed = true),
    SeedEx("Crunches", "Bauch/Core", "Körpergewicht"),
    SeedEx("Beinheben hängend", "Bauch/Core", "Körpergewicht"),
    SeedEx("Russian Twist", "Bauch/Core", "Kurzhantel"),
    // Ganzkörper
    SeedEx("Burpees", "Ganzkörper", "Körpergewicht"),
    SeedEx("Kettlebell Clean & Press", "Ganzkörper", "Kettlebell"),
)

private val seedWorkouts = listOf(
    SeedWorkout(
        "Ganzkörper A", "Klassisches Ganzkörpertraining, 2–3× pro Woche",
        listOf(
            SeedItem("Kniebeuge", 3, 8, 40f),
            SeedItem("Bankdrücken", 3, 8, 40f),
            SeedItem("Rudern vorgebeugt", 3, 8, 30f),
            SeedItem("Schulterdrücken", 3, 10, 10f),
            SeedItem("Plank", 3, 30),
        ),
    ),
    SeedWorkout(
        "Oberkörper Push", "Brust, Schultern, Trizeps",
        listOf(
            SeedItem("Bankdrücken", 4, 8, 40f),
            SeedItem("Schrägbankdrücken", 3, 10, 14f),
            SeedItem("Schulterdrücken", 3, 10, 10f),
            SeedItem("Seitheben", 3, 12, 5f),
            SeedItem("Trizepsdrücken", 3, 12, 20f),
        ),
    ),
    SeedWorkout(
        "Oberkörper Pull", "Rücken und Bizeps",
        listOf(
            SeedItem("Latzug", 4, 10, 40f),
            SeedItem("Einarmiges Rudern", 3, 10, 14f),
            SeedItem("Face Pulls", 3, 15, 15f),
            SeedItem("Bizepscurls", 3, 12, 8f),
            SeedItem("Hammercurls", 3, 12, 8f),
        ),
    ),
    SeedWorkout(
        "Beine & Gesäss", "Unterkörper-Tag",
        listOf(
            SeedItem("Kniebeuge", 4, 8, 40f),
            SeedItem("Rumänisches Kreuzheben", 3, 10, 40f),
            SeedItem("Ausfallschritte", 3, 10),
            SeedItem("Hip Thrusts", 3, 10, 40f),
            SeedItem("Wadenheben", 3, 15),
        ),
    ),
    SeedWorkout(
        "Home – Körpergewicht", "Ohne Equipment für zuhause",
        listOf(
            SeedItem("Liegestütze", 3, 10),
            SeedItem("Ausfallschritte", 3, 12),
            SeedItem("Glute Bridge", 3, 15),
            SeedItem("Pike-Liegestütze", 3, 8),
            SeedItem("Plank", 3, 30),
        ),
    ),
    SeedWorkout(
        "Kettlebell Express", "Kurz und intensiv mit einer Kettlebell",
        listOf(
            SeedItem("Goblet Squat", 3, 10, 12f),
            SeedItem("Kettlebell Swings", 4, 15, 16f),
            SeedItem("Kettlebell Clean & Press", 3, 8, 12f),
            SeedItem("Plank", 3, 30),
        ),
    ),
    SeedWorkout(
        "Core-Express", "15 Minuten für die Körpermitte",
        listOf(
            SeedItem("Plank", 3, 30),
            SeedItem("Crunches", 3, 15),
            SeedItem("Russian Twist", 3, 16, 4f),
            SeedItem("Seitstütz", 2, 20),
            SeedItem("Beinheben hängend", 3, 10),
        ),
    ),
)

/** Füllt Übungsbibliothek und vorgefertigte Workouts, falls die Datenbank leer ist. */
suspend fun seedDatabase(dao: AppDao) {
    if (dao.exerciseCount() > 0) return
    val exercises = seedExercises.map {
        Exercise(name = it.name, muscleGroup = it.muscle, equipment = it.equip, timed = it.timed)
    }
    val ids = dao.insertExercises(exercises)
    val idByName = seedExercises.mapIndexed { i, e -> e.name to ids[i] }.toMap()

    for (sw in seedWorkouts) {
        val workoutId = dao.insertWorkout(Workout(name = sw.name, isPreset = true, description = sw.description))
        val items = sw.items.mapIndexedNotNull { pos, item ->
            val exId = idByName[item.exercise] ?: return@mapIndexedNotNull null
            WorkoutExercise(
                workoutId = workoutId,
                exerciseId = exId,
                position = pos,
                sets = item.sets,
                reps = item.reps,
                weightKg = item.kg,
            )
        }
        dao.insertWorkoutExercises(items)
    }
}
