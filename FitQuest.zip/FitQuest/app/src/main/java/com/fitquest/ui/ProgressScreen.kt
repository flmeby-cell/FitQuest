package com.fitquest.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.dp
import com.fitquest.logic.Stats

@Composable
fun LevelCard(stats: Stats) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Level ${stats.level} · ${stats.levelTitle}", style = MaterialTheme.typography.headlineSmall)
            LinearProgressIndicator(
                progress = { (stats.xpIntoLevel / stats.xpForNextLevel.toFloat()).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth(),
            )
            Text("${stats.xpIntoLevel} / ${stats.xpForNextLevel} XP bis zum nächsten Level")
            Text(
                "Diese Woche: ${stats.thisWeekCount}/${stats.weeklyGoal} Einheiten" +
                    " · Serie: ${stats.streakWeeks} ${if (stats.streakWeeks == 1) "Woche" else "Wochen"}",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun StatTile(value: String, label: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge)
            Text(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun ProgressScreen(vm: AppViewModel) {
    val stats by vm.stats.collectAsState()
    val goals by vm.goals.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Fortschritt", style = MaterialTheme.typography.titleLarge)
        LevelCard(stats)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile("${stats.totalWorkouts}", "Workouts", Modifier.weight(1f))
            StatTile("${stats.totalSets}", "Sätze", Modifier.weight(1f))
            StatTile("%.1f t".format(stats.totalVolumeKg / 1000), "Volumen", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile("${stats.totalCardioSessions}", "Cardio-Einheiten", Modifier.weight(1f))
            StatTile("%.0f km".format(stats.totalCardioKm), "Cardio-Distanz", Modifier.weight(1f))
            StatTile("${stats.totalXp}", "XP gesamt", Modifier.weight(1f))
        }

        Card(Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column {
                    Text("Wochenziel", style = MaterialTheme.typography.titleSmall)
                    Text("${goals.weeklyWorkouts} Einheiten pro Woche", style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { vm.setGoals(goals.copy(weeklyWorkouts = (goals.weeklyWorkouts - 1).coerceAtLeast(1))) },
                    ) { Text("−") }
                    OutlinedButton(
                        onClick = { vm.setGoals(goals.copy(weeklyWorkouts = (goals.weeklyWorkouts + 1).coerceAtMost(7))) },
                    ) { Text("+") }
                }
            }
        }

        Text("Abzeichen", style = MaterialTheme.typography.titleMedium)
        stats.badges.forEach { badge ->
            Card(Modifier.fillMaxWidth().alpha(if (badge.unlocked) 1f else 0.4f)) {
                Row(
                    Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(if (badge.unlocked) badge.emoji else "🔒", style = MaterialTheme.typography.headlineSmall)
                    Column {
                        Text(badge.title, style = MaterialTheme.typography.titleSmall)
                        Text(badge.description, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
