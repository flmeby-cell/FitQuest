package com.fitquest.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fitquest.data.FoodEntry
import com.fitquest.data.Goals

@Composable
fun NutritionScreen(vm: AppViewModel) {
    var day by remember { mutableLongStateOf(today()) }
    val entries by remember(day) { vm.foodFor(day) }.collectAsState(emptyList<FoodEntry>())
    val goals by vm.goals.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var showGoals by remember { mutableStateOf(false) }

    val kcal = entries.sumOf { it.kcal }
    val remaining = goals.kcal - kcal

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { DayNavigator(day) { day = it } }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("$kcal kcal", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        if (remaining >= 0) "Noch $remaining von ${goals.kcal} kcal übrig"
                        else "${-remaining} kcal über dem Ziel von ${goals.kcal}",
                    )
                    LinearProgressIndicator(
                        progress = { (kcal / goals.kcal.toFloat()).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    MacroBar("Eiweiss", entries.sumOf { it.protein }, goals.protein)
                    MacroBar("Kohlenhydrate", entries.sumOf { it.carbs }, goals.carbs)
                    MacroBar("Fett", entries.sumOf { it.fat }, goals.fat)
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { showAdd = true }) { Text("Eintrag hinzufügen") }
                OutlinedButton(onClick = { showGoals = true }) { Text("Ziele") }
            }
        }

        items(entries, key = { it.id }) { entry ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(entry.name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            "${entry.kcal} kcal · E ${entry.protein} g · K ${entry.carbs} g · F ${entry.fat} g",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    IconButton(onClick = { vm.deleteFood(entry.id) }) { Icon(Icons.Filled.Delete, "Löschen") }
                }
            }
        }
    }

    if (showAdd) AddFoodDialog(
        onDismiss = { showAdd = false },
        onSave = { vm.addFood(it.copy(date = day)); showAdd = false },
    )
    if (showGoals) GoalsDialog(
        goals = goals,
        onDismiss = { showGoals = false },
        onSave = { vm.setGoals(it); showGoals = false },
    )
}

@Composable
private fun MacroBar(label: String, value: Int, goal: Int) {
    Column {
        Text("$label: $value / $goal g", style = MaterialTheme.typography.bodySmall)
        LinearProgressIndicator(
            progress = { (value / goal.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun AddFoodDialog(onDismiss: () -> Unit, onSave: (FoodEntry) -> Unit) {
    var name by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    var carbs by remember { mutableStateOf("") }
    var fat by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Eintrag hinzufügen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Name (optional)") },
                    singleLine = true,
                )
                NumField(kcal, { kcal = it }, "Kalorien (kcal)", Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(protein, { protein = it }, "Eiweiss g", Modifier.weight(1f))
                    NumField(carbs, { carbs = it }, "Kohlenh. g", Modifier.weight(1f))
                    NumField(fat, { fat = it }, "Fett g", Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = (kcal.toIntOrNull() ?: 0) > 0,
                onClick = {
                    onSave(
                        FoodEntry(
                            date = 0,
                            name = name.ifBlank { "Eintrag" },
                            kcal = kcal.toIntOrNull() ?: 0,
                            protein = protein.toIntOrNull() ?: 0,
                            carbs = carbs.toIntOrNull() ?: 0,
                            fat = fat.toIntOrNull() ?: 0,
                        ),
                    )
                },
            ) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}

@Composable
private fun GoalsDialog(goals: Goals, onDismiss: () -> Unit, onSave: (Goals) -> Unit) {
    var kcal by remember { mutableStateOf(goals.kcal.toString()) }
    var protein by remember { mutableStateOf(goals.protein.toString()) }
    var carbs by remember { mutableStateOf(goals.carbs.toString()) }
    var fat by remember { mutableStateOf(goals.fat.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tagesziele") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField(kcal, { kcal = it }, "Kalorien (kcal)", Modifier.fillMaxWidth())
                NumField(protein, { protein = it }, "Eiweiss (g)", Modifier.fillMaxWidth())
                NumField(carbs, { carbs = it }, "Kohlenhydrate (g)", Modifier.fillMaxWidth())
                NumField(fat, { fat = it }, "Fett (g)", Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        goals.copy(
                            kcal = (kcal.toIntOrNull() ?: goals.kcal).coerceAtLeast(1),
                            protein = protein.toIntOrNull() ?: goals.protein,
                            carbs = carbs.toIntOrNull() ?: goals.carbs,
                            fat = fat.toIntOrNull() ?: goals.fat,
                        ),
                    )
                },
            ) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}
