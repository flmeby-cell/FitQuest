package com.fitquest.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fitquest.data.Categories
import com.fitquest.data.Exercise
import com.fitquest.data.Workout
import com.fitquest.data.WorkoutExercise

@Composable
fun BuilderScreen(vm: AppViewModel, workoutId: Long, onDone: () -> Unit) {
    val exercises by vm.exercises.collectAsState()
    val byId = exercises.associateBy { it.id }

    var existing by remember { mutableStateOf<Workout?>(null) }
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    val items = remember { mutableStateListOf<WorkoutExercise>() }
    var showPicker by remember { mutableStateOf(false) }

    LaunchedEffect(workoutId) {
        if (workoutId >= 0) {
            val (w, list) = vm.loadWorkout(workoutId)
            existing = w
            name = w?.name ?: ""
            description = w?.description ?: ""
            items.clear()
            items.addAll(list)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onDone) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Zurück") }
            Text(
                if (workoutId >= 0) "Workout bearbeiten" else "Neues Workout",
                style = MaterialTheme.typography.titleLarge,
            )
        }

        LazyColumn(
            Modifier.weight(1f),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it }, label = { Text("Name") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = description, onValueChange = { description = it },
                        label = { Text("Beschreibung (optional)") }, modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            itemsIndexed(items) { idx, item ->
                val ex = byId[item.exerciseId]
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(ex?.name ?: "Unbekannt", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${ex?.muscleGroup ?: ""} · ${ex?.equipment ?: ""}",
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                            IconButton(
                                enabled = idx > 0,
                                onClick = { items.add(idx - 1, items.removeAt(idx)) },
                            ) { Icon(Icons.Filled.ArrowUpward, "Nach oben") }
                            IconButton(
                                enabled = idx < items.lastIndex,
                                onClick = { items.add(idx + 1, items.removeAt(idx)) },
                            ) { Icon(Icons.Filled.ArrowDownward, "Nach unten") }
                            IconButton(onClick = { items.removeAt(idx) }) { Icon(Icons.Filled.Delete, "Entfernen") }
                        }
                        val timed = ex?.timed == true
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Stepper("Sätze", item.sets.toString(),
                                onMinus = { items[idx] = item.copy(sets = (item.sets - 1).coerceAtLeast(1)) },
                                onPlus = { items[idx] = item.copy(sets = (item.sets + 1).coerceAtMost(10)) })
                            Stepper(if (timed) "Sek" else "Wdh", item.reps.toString(),
                                onMinus = { items[idx] = item.copy(reps = (item.reps - if (timed) 5 else 1).coerceAtLeast(1)) },
                                onPlus = { items[idx] = item.copy(reps = item.reps + if (timed) 5 else 1) })
                            if (!timed) {
                                Stepper("kg", fmtKg(item.weightKg),
                                    onMinus = { items[idx] = item.copy(weightKg = (item.weightKg - 2.5f).coerceAtLeast(0f)) },
                                    onPlus = { items[idx] = item.copy(weightKg = item.weightKg + 2.5f) })
                            }
                        }
                    }
                }
            }

            item {
                OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("+ Übung hinzufügen")
                }
            }
        }

        Button(
            enabled = name.isNotBlank() && items.isNotEmpty(),
            onClick = { vm.saveWorkout(existing, name, description, items.toList(), onSaved = onDone) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
        ) { Text("Speichern") }
    }

    if (showPicker) {
        ExercisePickerDialog(
            exercises = exercises,
            onDismiss = { showPicker = false },
            onPick = { ex ->
                items.add(
                    WorkoutExercise(
                        workoutId = 0, exerciseId = ex.id, position = items.size,
                        sets = 3, reps = if (ex.timed) 30 else 10, weightKg = 0f,
                    ),
                )
                showPicker = false
            },
        )
    }
}

@Composable
private fun Stepper(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onMinus, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) { Text("−") }
            Text(value, style = MaterialTheme.typography.titleSmall)
            TextButton(onClick = onPlus, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) { Text("+") }
        }
    }
}

@Composable
private fun ExercisePickerDialog(exercises: List<Exercise>, onDismiss: () -> Unit, onPick: (Exercise) -> Unit) {
    var query by remember { mutableStateOf("") }
    var muscle by remember { mutableStateOf<String?>(null) }
    var equipment by remember { mutableStateOf<String?>(null) }

    val filtered = exercises.filter {
        (muscle == null || it.muscleGroup == muscle) &&
            (equipment == null || it.equipment == equipment) &&
            it.name.contains(query, ignoreCase = true)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Übung wählen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, label = { Text("Suchen") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                ChipRow(Categories.muscleGroups, muscle, { muscle = it })
                ChipRow(Categories.equipment, equipment, { equipment = it })
                LazyColumn(Modifier.height(220.dp)) {
                    items(filtered, key = { it.id }) { ex ->
                        TextButton(onClick = { onPick(ex) }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(ex.name)
                                Text("${ex.muscleGroup} · ${ex.equipment}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Schliessen") } },
    )
}
