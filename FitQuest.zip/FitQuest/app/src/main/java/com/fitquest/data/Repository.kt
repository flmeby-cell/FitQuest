package com.fitquest.data

import android.content.Context
import com.fitquest.logic.Badge
import com.fitquest.logic.Effort
import com.fitquest.logic.Gamification
import com.fitquest.logic.Progression
import com.fitquest.logic.Stats
import com.fitquest.logic.Target
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import java.time.LocalDate

data class Goals(
    val kcal: Int = 2200,
    val protein: Int = 130,
    val carbs: Int = 250,
    val fat: Int = 70,
    val weeklyWorkouts: Int = 3,
)

data class DoneSet(val reps: Int, val weightKg: Float)

data class FinishedExercise(
    val target: WorkoutExercise,
    val exercise: Exercise,
    val sets: List<DoneSet>,
    val effort: Effort,
)

data class FinishResult(
    val xpGained: Int,
    val levelBefore: Int,
    val levelAfter: Int,
    val newBadges: List<Badge>,
    /** z. B. "Kniebeuge: 40 → 42.5 kg" */
    val adjustments: List<String>,
)

class Repository(context: Context) {
    private val dao = AppDatabase.get(context).dao()
    private val prefs = context.getSharedPreferences("fitquest", Context.MODE_PRIVATE)

    private val _goals = MutableStateFlow(loadGoals())
    val goals: StateFlow<Goals> = _goals.asStateFlow()

    val exercises = dao.exercises()
    val workouts = dao.workouts()
    val allWorkoutExercises = dao.allWorkoutExercises()
    val allPlanned = dao.allPlanned()
    val workoutLogs = dao.workoutLogs()
    val cardioLogs = dao.cardioLogs()

    val stats: Flow<Stats> = combine(
        dao.workoutLogs(), dao.cardioLogs(), dao.setCount(), dao.volume(), goals,
    ) { logs, cardio, sets, volume, g ->
        Gamification.stats(logs, cardio, sets, volume, g.weeklyWorkouts)
    }

    fun foodForDay(day: Long) = dao.foodForDay(day)
    fun setLogsForDate(day: Long) = dao.setLogsForDate(day)

    suspend fun seedIfEmpty() = seedDatabase(dao)

    // ---- Übungen ----
    suspend fun exercise(id: Long) = dao.exercise(id)
    suspend fun addExercise(e: Exercise) = dao.insertExercise(e.copy(isCustom = true))
    suspend fun deleteExercise(e: Exercise) {
        dao.deleteWorkoutExercisesByExercise(e.id)
        dao.deleteExercise(e)
    }

    // ---- Workouts ----
    suspend fun workout(id: Long) = dao.workout(id)
    suspend fun workoutExercises(id: Long) = dao.workoutExercises(id)

    /** Legt ein Workout an oder aktualisiert es; [items] werden mit neuer Reihenfolge gespeichert. */
    suspend fun saveWorkout(existing: Workout?, name: String, description: String, items: List<WorkoutExercise>): Long {
        val id = if (existing == null) {
            dao.insertWorkout(Workout(name = name, description = description))
        } else {
            dao.updateWorkout(existing.copy(name = name, description = description))
            dao.deleteWorkoutExercises(existing.id)
            existing.id
        }
        dao.insertWorkoutExercises(
            items.mapIndexed { i, it -> it.copy(id = 0, workoutId = id, position = i) },
        )
        return id
    }

    suspend fun deleteWorkout(id: Long) {
        dao.deleteWorkoutExercises(id)
        dao.deletePlannedForWorkout(id)
        dao.deleteWorkout(id)
    }

    suspend fun duplicateWorkout(id: Long) {
        val w = dao.workout(id) ?: return
        val items = dao.workoutExercises(id)
        val newId = dao.insertWorkout(Workout(name = "${w.name} (Kopie)", description = w.description))
        dao.insertWorkoutExercises(items.map { it.copy(id = 0, workoutId = newId) })
    }

    // ---- Planung ----
    suspend fun plan(day: Long, workoutId: Long) {
        dao.insertPlanned(PlannedWorkout(date = day, workoutId = workoutId))
    }

    suspend fun unplan(id: Long) = dao.deletePlanned(id)

    // ---- Training abschliessen ----
    suspend fun finishWorkout(workout: Workout, durationSec: Int, items: List<FinishedExercise>): FinishResult {
        val before = stats.first()
        if (items.isEmpty()) {
            return FinishResult(0, before.level, before.level, emptyList(), emptyList())
        }

        val today = LocalDate.now().toEpochDay()
        val totalSets = items.sumOf { it.sets.size }
        val xp = Gamification.workoutXp(totalSets)
        val logId = dao.insertLog(
            WorkoutLog(
                date = today,
                workoutId = workout.id,
                workoutName = workout.name,
                durationSec = durationSec,
                xp = xp,
            ),
        )

        dao.insertSetLogs(
            items.flatMap { item ->
                item.sets.mapIndexed { i, set ->
                    SetLog(
                        logId = logId,
                        date = today,
                        exerciseId = item.exercise.id,
                        exerciseName = item.exercise.name,
                        setIndex = i,
                        reps = set.reps,
                        weightKg = set.weightKg,
                        timed = item.exercise.timed,
                        effort = item.effort.label,
                    )
                }
            },
        )

        // Zielwerte fürs nächste Mal anpassen
        val adjustments = mutableListOf<String>()
        val updated = items.map { item ->
            val we = item.target
            val allDone = item.sets.size >= we.sets && item.sets.all { it.reps >= we.reps }
            val next = Progression.next(
                Target(we.sets, we.reps, we.weightKg), item.effort, allDone, item.exercise.timed,
            )
            describeChange(item.exercise, we, next)?.let { adjustments += it }
            we.copy(sets = next.sets, reps = next.reps, weightKg = next.weightKg)
        }
        dao.updateWorkoutExercises(updated)

        val after = stats.first()
        val unlockedBefore = before.badges.filter { it.unlocked }.map { it.id }.toSet()
        val newBadges = after.badges.filter { it.unlocked && it.id !in unlockedBefore }
        return FinishResult(xp, before.level, after.level, newBadges, adjustments)
    }

    private fun describeChange(ex: Exercise, old: WorkoutExercise, new: Target): String? {
        if (old.sets == new.sets && old.reps == new.reps && old.weightKg == new.weightKg) return null
        val unit = if (ex.timed) "s" else "Wdh"
        val parts = mutableListOf<String>()
        if (old.weightKg != new.weightKg) parts += "${fmt(old.weightKg)} → ${fmt(new.weightKg)} kg"
        if (old.reps != new.reps) parts += "${old.reps} → ${new.reps} $unit"
        if (old.sets != new.sets) parts += "${old.sets} → ${new.sets} Sätze"
        return "${ex.name}: ${parts.joinToString(", ")}"
    }

    private fun fmt(w: Float): String = if (w == w.toInt().toFloat()) w.toInt().toString() else w.toString()

    // ---- Cardio ----
    suspend fun addCardio(c: CardioLog) {
        dao.insertCardio(c.copy(xp = Gamification.cardioXp(c.durationSec, c.distanceKm)))
    }

    /** Gibt die Anzahl neu importierter Einheiten zurück (Duplikate werden ignoriert). */
    suspend fun importCardio(list: List<CardioLog>): Int = list.count { dao.insertCardio(it) != -1L }

    suspend fun deleteCardio(id: Long) = dao.deleteCardio(id)

    // ---- Ernährung ----
    suspend fun addFood(f: FoodEntry) = dao.insertFood(f)
    suspend fun deleteFood(id: Long) = dao.deleteFood(id)

    fun setGoals(g: Goals) {
        prefs.edit()
            .putInt("kcal", g.kcal).putInt("protein", g.protein)
            .putInt("carbs", g.carbs).putInt("fat", g.fat)
            .putInt("weekly", g.weeklyWorkouts)
            .apply()
        _goals.value = g
    }

    private fun loadGoals(): Goals {
        val d = Goals()
        return Goals(
            kcal = prefs.getInt("kcal", d.kcal),
            protein = prefs.getInt("protein", d.protein),
            carbs = prefs.getInt("carbs", d.carbs),
            fat = prefs.getInt("fat", d.fat),
            weeklyWorkouts = prefs.getInt("weekly", d.weeklyWorkouts),
        )
    }
}
