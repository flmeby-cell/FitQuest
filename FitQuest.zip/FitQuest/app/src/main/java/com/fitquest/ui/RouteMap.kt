package com.fitquest.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

fun parseRoute(encoded: String?): List<Pair<Double, Double>> =
    encoded?.split(';')?.mapNotNull { part ->
        val p = part.split(',')
        val lat = p.getOrNull(0)?.toDoubleOrNull()
        val lon = p.getOrNull(1)?.toDoubleOrNull()
        if (lat != null && lon != null) lat to lon else null
    } ?: emptyList()

/** Zeichnet die GPS-Strecke als Linie (ohne Kartenhintergrund, daher kein API-Key nötig). */
@Composable
fun RouteMap(points: List<Pair<Double, Double>>, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.primary
    val background = MaterialTheme.colorScheme.surfaceVariant
    Canvas(
        modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(background),
    ) {
        if (points.size < 2) return@Canvas
        val latMin = points.minOf { it.first }
        val latMax = points.maxOf { it.first }
        val lonMin = points.minOf { it.second }
        val lonMax = points.maxOf { it.second }

        val k = cos(Math.toRadians((latMin + latMax) / 2))
        val w = (lonMax - lonMin) * k
        val h = latMax - latMin
        val pad = 16.dp.toPx()
        val scale = min(
            (size.width - 2 * pad) / max(w, 1e-9),
            (size.height - 2 * pad) / max(h, 1e-9),
        )
        val offX = (size.width - w * scale) / 2
        val offY = (size.height - h * scale) / 2

        fun toOffset(p: Pair<Double, Double>) = Offset(
            ((p.second - lonMin) * k * scale + offX).toFloat(),
            (size.height - ((p.first - latMin) * scale + offY)).toFloat(),
        )

        val path = Path()
        points.forEachIndexed { i, p ->
            val o = toOffset(p)
            if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
        }
        drawPath(path, lineColor, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(Color(0xFF2E7D32), 6.dp.toPx(), toOffset(points.first()))
        drawCircle(Color(0xFFC62828), 6.dp.toPx(), toOffset(points.last()))
    }
}
