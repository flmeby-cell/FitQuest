package com.fitquest.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

fun today(): Long = LocalDate.now().toEpochDay()

fun fmtKg(w: Float): String = if (w == w.toInt().toFloat()) w.toInt().toString() else w.toString()

fun fmtDay(day: Long, pattern: String = "EEE, d. MMM"): String =
    LocalDate.ofEpochDay(day).format(DateTimeFormatter.ofPattern(pattern, Locale.GERMAN))

fun fmtDuration(sec: Int): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

/** Pace in min/km, null wenn keine Distanz vorhanden ist. */
fun fmtPace(durationSec: Int, km: Double): String? {
    if (km <= 0.0) return null
    val p = durationSec / km
    return "%d:%02d min/km".format((p / 60).toInt(), (p % 60).toInt())
}

fun String.toFloatLoose(): Float? = replace(',', '.').toFloatOrNull()

@Composable
fun DayNavigator(day: Long, onChange: (Long) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        IconButton(onClick = { onChange(day - 1) }) { Icon(Icons.Filled.ChevronLeft, "Vorheriger Tag") }
        Text(
            if (day == today()) "Heute" else fmtDay(day, "EEE, d. MMM yyyy"),
            style = MaterialTheme.typography.titleMedium,
        )
        IconButton(onClick = { onChange(day + 1) }) { Icon(Icons.Filled.ChevronRight, "Nächster Tag") }
    }
}

@Composable
fun NumField(
    value: String,
    onValue: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    decimal: Boolean = false,
) {
    OutlinedTextField(
        value = value,
        onValueChange = { text -> onValue(text.filter { it.isDigit() || (decimal && (it == '.' || it == ',')) }) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number),
        modifier = modifier,
    )
}
