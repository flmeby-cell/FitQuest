package com.fitquest.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fitquest.logic.Effort
import kotlinx.coroutines.delay

@Composable
fun ActiveWorkoutScreen(vm: AppViewModel, workoutId: Long, onExit: () -> Unit) {
    LaunchedEffect(workoutId) { vm.startWorkout(workoutId) }
    val session by vm.session.collectAsState()
    val result by vm.result.collectAsState()
    var confirmExit by remember { mutableStateOf(false) }
    var askEffort by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }

    BackHandler {
        if (result != null) {
            vm.clearSession(); onExit()
        } else confirmExit = true
    }

    val s = session
    if (s == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    val elapsed by produceState(0, s.startedAtMs) {
        while (true) {
            value = ((System.currentTimeMillis() - s.startedAtMs) / 1000).toInt()
            delay(1000)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(s.workout.name, style = MaterialTheme.typography.titleLarge)
            Text(fmtDuration(elapsed), style = MaterialTheme.typography.titleMedium)
        }
        LinearProgressIndicator(
            progress = { (s.index / s.items.size.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
        )

        if (s.index < s.items.size) {
            val item = s.items[s.index]
            val timed = item.exercise.timed
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("Übung ${s.index + 1} von ${s.items.size}", style = MaterialTheme.typography.labelMedium)
                Text(item.exercise.name, style = MaterialTheme.typography.headlineSmall)
                Text(
                    "${item.exercise.muscleGroup} · ${item.exercise.equipment}",
                    style = MaterialTheme.typography.bodySmall,
                )
                val t = item.target
                Text(
                    when {
                        timed -> "Ziel: ${t.sets} × ${t.reps} s"
                        t.weightKg > 0f -> "Ziel: ${t.sets} × ${t.reps} @ ${fmtKg(t.weightKg)} kg"
                        else -> "Ziel: ${t.sets} × ${t.reps}"
                    },
                    style = MaterialTheme.typography.titleSmall,
                )

                item.sets.forEachIndexed { j, set ->
                    key(s.index, j) {
                        SetRow(j + 1, set, timed) { vm.updateSet(s.index, j, it) }
                    }
                }
                TextButton(onClick = { vm.addSet(s.index) }) { Text("+ Satz hinzufügen") }
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (s.index > 0) OutlinedButton(onClick = { vm.previousExercise() }) { Text("Zurück") }
                TextButton(onClick = { vm.skipExercise() }) { Text("Überspringen") }
                Button(onClick = { askEffort = true }, modifier = Modifier.weight(1f)) { Text("Übung abschliessen") }
            }
        } else {
            val doneSets = s.items.sumOf { it.sets.count { set -> set.done } }
            Column(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Training geschafft 🎉", style = MaterialTheme.typography.headlineMedium)
                Text("$doneSets Sätze abgehakt · ${fmtDuration(elapsed)}")
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.previousExercise() }) { Text("Zurück") }
                Button(
                    enabled = !saving,
                    onClick = { saving = true; vm.saveSession() },
                    modifier = Modifier.weight(1f),
                ) { Text("Training speichern") }
            }
        }
    }

    if (askEffort && s.index < s.items.size) {
        AlertDialog(
            onDismissRequest = { askEffort = false },
            title = { Text("Wie anstrengend war „${s.items[s.index].exercise.name}“?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Effort.entries.forEach { effort ->
                        OutlinedButton(
                            onClick = { askEffort = false; vm.completeExercise(effort) },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(effort.label)
                                Text(effort.hint, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { askEffort = false }) { Text("Abbrechen") } },
        )
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Training abbrechen?") },
            text = { Text("Nicht gespeicherte Sätze gehen verloren.") },
            confirmButton = {
                TextButton(onClick = { confirmExit = false; vm.clearSession(); onExit() }) { Text("Abbrechen") }
            },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Weitermachen") } },
        )
    }

    result?.let { r ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(if (r.xpGained > 0) "Gespeichert!" else "Nichts gespeichert") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (r.xpGained == 0) {
                        Text("Es wurde kein Satz abgehakt.")
                    } else {
                        Text("+${r.xpGained} XP", style = MaterialTheme.typography.titleMedium)
                        if (r.levelAfter > r.levelBefore) Text("Level-Up! Du bist jetzt Level ${r.levelAfter} 🎉")
                        r.newBadges.forEach { Text("${it.emoji} Neues Abzeichen: ${it.title}") }
                        if (r.adjustments.isNotEmpty()) {
                            Text("Nächstes Mal:", style = MaterialTheme.typography.titleSmall)
                            r.adjustments.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.clearSession(); onExit() }) { Text("Fertig") } },
        )
    }
}

@Composable
private fun SetRow(number: Int, set: SetState, timed: Boolean, onChange: (SetState) -> Unit) {
    var reps by remember { mutableStateOf(set.reps.toString()) }
    var kg by remember { mutableStateOf(fmtKg(set.weight)) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("$number", Modifier.width(20.dp))
        NumField(
            value = reps,
            onValue = { reps = it; onChange(set.copy(reps = it.toIntOrNull() ?: 0)) },
            label = if (timed) "Sek" else "Wdh",
            modifier = Modifier.weight(1f),
        )
        if (!timed) {
            NumField(
                value = kg,
                onValue = { kg = it; onChange(set.copy(weight = it.toFloatLoose() ?: 0f)) },
                label = "kg",
                modifier = Modifier.weight(1f),
                decimal = true,
            )
        }
        Checkbox(checked = set.done, onCheckedChange = { onChange(set.copy(done = it)) })
    }
}
