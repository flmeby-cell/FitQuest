package com.fitquest.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.fitquest.data.SetLog
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun CalendarScreen(vm: AppViewModel, onStart: (Long) -> Unit) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableLongStateOf(today()) }
    var showPlan by remember { mutableStateOf(false) }

    val planned by vm.planned.collectAsState()
    val workouts by vm.workouts.collectAsState()
    val logs by vm.workoutLogs.collectAsState()
    val cardio by vm.cardioLogs.collectAsState()
    val setLogs by remember(selected) { vm.setLogsFor(selected) }.collectAsState(emptyList<SetLog>())

    val loggedDays = remember(logs, cardio) { (logs.map { it.date } + cardio.map { it.date }).toSet() }
    val plannedDays = remember(planned) { planned.map { it.date }.toSet() }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Filled.ChevronLeft, "Vorheriger Monat") }
            Text(
                month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.GERMAN)),
                style = MaterialTheme.typography.titleMedium,
            )
            IconButton(onClick = { month = month.plusMonths(1) }) { Icon(Icons.Filled.ChevronRight, "Nächster Monat") }
        }

        Row(Modifier.fillMaxWidth()) {
            listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So").forEach {
                Text(
                    it, Modifier.weight(1f), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelMedium,
                )
            }
        }

        val offset = month.atDay(1).dayOfWeek.value - 1
        val length = month.lengthOfMonth()
        val rows = (offset + length + 6) / 7
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0..6) {
                    val n = r * 7 + c - offset + 1
                    if (n in 1..length) {
                        val day = month.atDay(n).toEpochDay()
                        DayCell(
                            number = n,
                            isSelected = day == selected,
                            isToday = day == today(),
                            logged = day in loggedDays,
                            planned = day in plannedDays,
                            modifier = Modifier.weight(1f),
                            onClick = { selected = day },
                        )
                    } else {
                        Spacer(Modifier.weight(1f).aspectRatio(1f))
                    }
                }
            }
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text(fmtDay(selected, "EEEE, d. MMMM"), style = MaterialTheme.typography.titleMedium)

        // Geplant
        planned.filter { it.date == selected }.forEach { p ->
            val workout = workouts.firstOrNull { it.id == p.workoutId } ?: return@forEach
            val done = logs.any { it.date == selected && it.workoutId == p.workoutId }
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(workout.name, style = MaterialTheme.typography.titleSmall)
                        Text(if (done) "Geplant · erledigt ✓" else "Geplant", style = MaterialTheme.typography.bodySmall)
                    }
                    if (!done) TextButton(onClick = { onStart(workout.id) }) { Text("Start") }
                    IconButton(onClick = { vm.unplan(p.id) }) { Icon(Icons.Filled.Delete, "Planung entfernen") }
                }
            }
        }
        OutlinedButton(onClick = { showPlan = true }, modifier = Modifier.fillMaxWidth()) { Text("Workout planen") }

        // Geloggt
        logs.filter { it.date == selected }.forEach { log ->
            val perExercise = setLogs.filter { it.logId == log.id }.groupBy { it.exerciseName }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "✓ ${log.workoutName} · ${fmtDuration(log.durationSec)} · +${log.xp} XP",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    perExercise.forEach { (name, sets) ->
                        val summary = sets.joinToString(", ") {
                            when {
                                it.timed -> "${it.reps} s"
                                it.weightKg > 0f -> "${it.reps}×${fmtKg(it.weightKg)} kg"
                                else -> "${it.reps}"
                            }
                        }
                        Text(
                            "$name: $summary · ${sets.first().effort}",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
        cardio.filter { it.date == selected }.forEach { c ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("✓ ${c.type} · +${c.xp} XP", style = MaterialTheme.typography.titleSmall)
                    Text(
                        listOfNotNull(
                            fmtDuration(c.durationSec),
                            if (c.distanceKm > 0) "%.2f km".format(c.distanceKm) else null,
                            fmtPace(c.durationSec, c.distanceKm),
                            if (c.kcal > 0) "${c.kcal} kcal" else null,
                        ).joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
    }

    if (showPlan) {
        AlertDialog(
            onDismissRequest = { showPlan = false },
            title = { Text("Workout für ${fmtDay(selected)}") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    workouts.forEach { w ->
                        TextButton(
                            onClick = { vm.plan(selected, w.id); showPlan = false },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(w.name, Modifier.fillMaxWidth()) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showPlan = false }) { Text("Abbrechen") } },
        )
    }
}

@Composable
private fun DayCell(
    number: Int,
    isSelected: Boolean,
    isToday: Boolean,
    logged: Boolean,
    planned: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val primary = MaterialTheme.colorScheme.primary
    Box(
        modifier
            .aspectRatio(1f)
            .padding(2.dp)
            .clip(CircleShape)
            .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .then(if (isToday) Modifier.border(1.dp, primary, CircleShape) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$number", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.size(width = 16.dp, height = 6.dp)) {
                if (logged) Box(Modifier.size(6.dp).clip(CircleShape).background(primary))
                if (planned && !logged) Box(Modifier.size(6.dp).clip(CircleShape).border(1.dp, primary, CircleShape))
            }
        }
    }
}
