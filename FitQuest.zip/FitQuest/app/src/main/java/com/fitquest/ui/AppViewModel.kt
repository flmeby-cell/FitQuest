package com.fitquest.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fitquest.data.CardioLog
import com.fitquest.data.DoneSet
import com.fitquest.data.Exercise
import com.fitquest.data.FinishResult
import com.fitquest.data.FinishedExercise
import com.fitquest.data.FoodEntry
import com.fitquest.data.Goals
import com.fitquest.data.Repository
import com.fitquest.data.SetLog
import com.fitquest.data.Workout
import com.fitquest.data.WorkoutExercise
import com.fitquest.logic.Effort
import com.fitquest.logic.Stats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SetState(val reps: Int, val weight: Float, val done: Boolean = false)

data class ActiveExercise(
    val target: WorkoutExercise,
    val exercise: Exercise,
    val sets: List<SetState>,
    val effort: Effort? = null,
)

data class ActiveSession(
    val workout: Workout,
    val items: List<ActiveExercise>,
    val index: Int = 0,
    val startedAtMs: Long = System.currentTimeMillis(),
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)

    private fun <T> Flow<T>.state(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)

    val exercises = repo.exercises.state(emptyList())
    val workouts = repo.workouts.state(emptyList())
    val workoutExercises = repo.allWorkoutExercises.state(emptyList())
    val planned = repo.allPlanned.state(emptyList())
    val workoutLogs = repo.workoutLogs.state(emptyList())
    val cardioLogs = repo.cardioLogs.state(emptyList())
    val stats = repo.stats.state(Stats())
    val goals: StateFlow<Goals> = repo.goals

    init {
        viewModelScope.launch { repo.seedIfEmpty() }
    }

    fun foodFor(day: Long): Flow<List<FoodEntry>> = repo.foodForDay(day)
    fun setLogsFor(day: Long): Flow<List<SetLog>> = repo.setLogsForDate(day)

    // ---- Bibliothek ----
    fun addExercise(name: String, muscle: String, equipment: String, timed: Boolean) = viewModelScope.launch {
        repo.addExercise(Exercise(name = name.trim(), muscleGroup = muscle, equipment = equipment, timed = timed))
    }

    fun deleteExercise(e: Exercise) = viewModelScope.launch { repo.deleteExercise(e) }

    // ---- Workouts ----
    suspend fun loadWorkout(id: Long): Pair<Workout?, List<WorkoutExercise>> =
        repo.workout(id) to repo.workoutExercises(id)

    fun saveWorkout(
        existing: Workout?, name: String, description: String, items: List<WorkoutExercise>,
        onSaved: () -> Unit,
    ) = viewModelScope.launch {
        repo.saveWorkout(existing, name.trim(), description.trim(), items)
        onSaved()
    }

    fun deleteWorkout(id: Long) = viewModelScope.launch { repo.deleteWorkout(id) }
    fun duplicateWorkout(id: Long) = viewModelScope.launch { repo.duplicateWorkout(id) }

    // ---- Planung ----
    fun plan(day: Long, workoutId: Long) = viewModelScope.launch { repo.plan(day, workoutId) }
    fun unplan(id: Long) = viewModelScope.launch { repo.unplan(id) }

    // ---- Aktives Training ----
    private val _session = MutableStateFlow<ActiveSession?>(null)
    val session: StateFlow<ActiveSession?> = _session.asStateFlow()

    private val _result = MutableStateFlow<FinishResult?>(null)
    val result: StateFlow<FinishResult?> = _result.asStateFlow()

    fun startWorkout(id: Long) = viewModelScope.launch {
        if (_session.value?.workout?.id == id) return@launch
        val workout = repo.workout(id) ?: return@launch
        val items = repo.workoutExercises(id).mapNotNull { we ->
            repo.exercise(we.exerciseId)?.let { ex ->
                ActiveExercise(we, ex, List(we.sets) { SetState(we.reps, we.weightKg) })
            }
        }
        _session.value = ActiveSession(workout, items)
        _result.value = null
    }

    private fun updateSession(block: (ActiveSession) -> ActiveSession) = _session.update { it?.let(block) }

    fun updateSet(item: Int, set: Int, state: SetState) = updateSession { s ->
        s.copy(items = s.items.mapIndexed { i, ex ->
            if (i != item) ex else ex.copy(sets = ex.sets.mapIndexed { j, old -> if (j == set) state else old })
        })
    }

    fun addSet(item: Int) = updateSession { s ->
        s.copy(items = s.items.mapIndexed { i, ex ->
            if (i != item) ex else ex.copy(sets = ex.sets + ex.sets.last().copy(done = false))
        })
    }

    /** Schliesst die aktuelle Übung mit der Anstrengung ab und springt zur nächsten. */
    fun completeExercise(effort: Effort) = updateSession { s ->
        s.copy(
            items = s.items.mapIndexed { i, ex -> if (i == s.index) ex.copy(effort = effort) else ex },
            index = s.index + 1,
        )
    }

    fun skipExercise() = updateSession { it.copy(index = it.index + 1) }
    fun previousExercise() = updateSession { it.copy(index = (it.index - 1).coerceAtLeast(0)) }

    fun saveSession() = viewModelScope.launch {
        val s = _session.value ?: return@launch
        val finished = s.items.mapNotNull { item ->
            val done = item.sets.filter { it.done }
            if (done.isEmpty()) null
            else FinishedExercise(
                target = item.target,
                exercise = item.exercise,
                sets = done.map { DoneSet(it.reps, it.weight) },
                effort = item.effort ?: Effort.OK,
            )
        }
        val duration = ((System.currentTimeMillis() - s.startedAtMs) / 1000).toInt()
        _result.value = repo.finishWorkout(s.workout, duration, finished)
    }

    fun clearSession() {
        _session.value = null
        _result.value = null
    }

    // ---- Cardio ----
    fun addCardio(log: CardioLog) = viewModelScope.launch { repo.addCardio(log) }
    fun deleteCardio(id: Long) = viewModelScope.launch { repo.deleteCardio(id) }
    suspend fun importCardio(list: List<CardioLog>): Int = repo.importCardio(list)

    // ---- Ernährung ----
    fun addFood(entry: FoodEntry) = viewModelScope.launch { repo.addFood(entry) }
    fun deleteFood(id: Long) = viewModelScope.launch { repo.deleteFood(id) }
    fun setGoals(g: Goals) = repo.setGoals(g)
}
