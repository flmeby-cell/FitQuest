package com.fitquest.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // ---- Übungen ----
    @Query("SELECT * FROM exercises ORDER BY name")
    fun exercises(): Flow<List<Exercise>>

    @Query("SELECT COUNT(*) FROM exercises")
    suspend fun exerciseCount(): Int

    @Query("SELECT * FROM exercises WHERE id = :id")
    suspend fun exercise(id: Long): Exercise?

    @Insert
    suspend fun insertExercise(e: Exercise): Long

    @Insert
    suspend fun insertExercises(list: List<Exercise>): List<Long>

    @Delete
    suspend fun deleteExercise(e: Exercise)

    @Query("DELETE FROM workout_exercises WHERE exerciseId = :exerciseId")
    suspend fun deleteWorkoutExercisesByExercise(exerciseId: Long)

    // ---- Workouts ----
    @Query("SELECT * FROM workouts ORDER BY isPreset DESC, name")
    fun workouts(): Flow<List<Workout>>

    @Query("SELECT * FROM workouts WHERE id = :id")
    suspend fun workout(id: Long): Workout?

    @Insert
    suspend fun insertWorkout(w: Workout): Long

    @Update
    suspend fun updateWorkout(w: Workout)

    @Query("DELETE FROM workouts WHERE id = :id")
    suspend fun deleteWorkout(id: Long)

    @Query("SELECT * FROM workout_exercises ORDER BY workoutId, position")
    fun allWorkoutExercises(): Flow<List<WorkoutExercise>>

    @Query("SELECT * FROM workout_exercises WHERE workoutId = :id ORDER BY position")
    suspend fun workoutExercises(id: Long): List<WorkoutExercise>

    @Insert
    suspend fun insertWorkoutExercises(list: List<WorkoutExercise>)

    @Update
    suspend fun updateWorkoutExercises(list: List<WorkoutExercise>)

    @Query("DELETE FROM workout_exercises WHERE workoutId = :id")
    suspend fun deleteWorkoutExercises(id: Long)

    // ---- Planung ----
    @Query("SELECT * FROM planned_workouts ORDER BY date")
    fun allPlanned(): Flow<List<PlannedWorkout>>

    @Insert
    suspend fun insertPlanned(p: PlannedWorkout): Long

    @Query("DELETE FROM planned_workouts WHERE id = :id")
    suspend fun deletePlanned(id: Long)

    @Query("DELETE FROM planned_workouts WHERE workoutId = :workoutId")
    suspend fun deletePlannedForWorkout(workoutId: Long)

    // ---- Logs ----
    @Query("SELECT * FROM workout_logs ORDER BY date DESC, id DESC")
    fun workoutLogs(): Flow<List<WorkoutLog>>

    @Insert
    suspend fun insertLog(l: WorkoutLog): Long

    @Insert
    suspend fun insertSetLogs(list: List<SetLog>)

    @Query("SELECT * FROM set_logs WHERE date = :date ORDER BY logId, id")
    fun setLogsForDate(date: Long): Flow<List<SetLog>>

    @Query("SELECT COUNT(*) FROM set_logs")
    fun setCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(reps * weightKg), 0.0) FROM set_logs WHERE timed = 0")
    fun volume(): Flow<Double>

    // ---- Cardio ----
    @Query("SELECT * FROM cardio_logs ORDER BY date DESC, id DESC")
    fun cardioLogs(): Flow<List<CardioLog>>

    /** Gibt -1 zurück, wenn die externalId schon existiert (Duplikat beim Import). */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCardio(c: CardioLog): Long

    @Query("DELETE FROM cardio_logs WHERE id = :id")
    suspend fun deleteCardio(id: Long)

    // ---- Ernährung ----
    @Query("SELECT * FROM food_entries WHERE date = :date ORDER BY id")
    fun foodForDay(date: Long): Flow<List<FoodEntry>>

    @Insert
    suspend fun insertFood(f: FoodEntry): Long

    @Query("DELETE FROM food_entries WHERE id = :id")
    suspend fun deleteFood(id: Long)
}
