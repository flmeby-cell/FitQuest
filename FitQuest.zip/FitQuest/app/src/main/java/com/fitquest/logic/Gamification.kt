package com.fitquest.logic

import com.fitquest.data.CardioLog
import com.fitquest.data.WorkoutLog
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import kotlin.math.floor
import kotlin.math.sqrt

data class Badge(
    val id: String,
    val emoji: String,
    val title: String,
    val description: String,
    val unlocked: Boolean,
)

data class Stats(
    val totalXp: Int = 0,
    val level: Int = 1,
    val xpIntoLevel: Int = 0,
    val xpForNextLevel: Int = 100,
    val levelTitle: String = "Einsteiger",
    val totalWorkouts: Int = 0,
    val totalCardioSessions: Int = 0,
    val totalSets: Int = 0,
    val totalVolumeKg: Double = 0.0,
    val totalCardioKm: Double = 0.0,
    val streakWeeks: Int = 0,
    val thisWeekCount: Int = 0,
    val weeklyGoal: Int = 3,
    val badges: List<Badge> = emptyList(),
)

object Gamification {
    private val titles = listOf(
        "Einsteiger", "Starter", "Aktiv", "Routinier", "Kämpfer",
        "Athlet", "Profi", "Elite", "Legende",
    )

    fun workoutXp(completedSets: Int): Int = 50 + completedSets.coerceAtMost(30) * 5

    fun cardioXp(durationSec: Int, distanceKm: Double): Int =
        20 + (durationSec / 60).coerceAtMost(120) + (distanceKm * 5).toInt().coerceAtMost(100)

    /** Level n startet bei 50 * n * (n - 1) XP: 0, 100, 300, 600, 1000 ... */
    private fun thresholdFor(level: Int): Int = 50 * level * (level - 1)

    fun levelFor(xp: Int): Int = floor((1 + sqrt(1 + xp / 12.5)) / 2).toInt().coerceAtLeast(1)

    /** Rückgabe: (Wochenserie, Einheiten in dieser Woche). Eine Woche zählt, wenn das Wochenziel erreicht ist. */
    fun weeklyStreak(dates: List<Long>, goal: Int, today: LocalDate = LocalDate.now()): Pair<Int, Int> {
        fun weekStart(d: LocalDate): Long =
            d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toEpochDay()

        val perWeek = dates.groupingBy { weekStart(LocalDate.ofEpochDay(it)) }.eachCount()
        val currentWeek = weekStart(today)
        val thisWeek = perWeek[currentWeek] ?: 0

        var streak = if (thisWeek >= goal) 1 else 0
        var week = currentWeek - 7
        while ((perWeek[week] ?: 0) >= goal) {
            streak++
            week -= 7
        }
        return streak to thisWeek
    }

    fun stats(
        logs: List<WorkoutLog>,
        cardio: List<CardioLog>,
        totalSets: Int,
        totalVolumeKg: Double,
        weeklyGoal: Int,
    ): Stats {
        val xp = logs.sumOf { it.xp } + cardio.sumOf { it.xp }
        val level = levelFor(xp)
        val start = thresholdFor(level)
        val next = thresholdFor(level + 1)
        val (streak, thisWeek) = weeklyStreak(logs.map { it.date } + cardio.map { it.date }, weeklyGoal)
        val km = cardio.sumOf { it.distanceKm }

        val base = Stats(
            totalXp = xp,
            level = level,
            xpIntoLevel = xp - start,
            xpForNextLevel = next - start,
            levelTitle = titles[((level - 1) / 2).coerceAtMost(titles.lastIndex)],
            totalWorkouts = logs.size,
            totalCardioSessions = cardio.size,
            totalSets = totalSets,
            totalVolumeKg = totalVolumeKg,
            totalCardioKm = km,
            streakWeeks = streak,
            thisWeekCount = thisWeek,
            weeklyGoal = weeklyGoal,
        )
        return base.copy(badges = badges(base))
    }

    private fun badges(s: Stats): List<Badge> = listOf(
        Badge("first", "🌱", "Erster Schritt", "Erstes Workout abgeschlossen", s.totalWorkouts >= 1),
        Badge("w10", "💪", "Dranbleiber", "10 Workouts abgeschlossen", s.totalWorkouts >= 10),
        Badge("w50", "🏅", "Stammgast", "50 Workouts abgeschlossen", s.totalWorkouts >= 50),
        Badge("sets100", "🔁", "Satzmaschine", "100 Sätze absolviert", s.totalSets >= 100),
        Badge("vol10", "🏋️", "10-Tonnen-Club", "10 000 kg Gesamtvolumen bewegt", s.totalVolumeKg >= 10_000),
        Badge("vol100", "🦍", "100-Tonnen-Club", "100 000 kg Gesamtvolumen bewegt", s.totalVolumeKg >= 100_000),
        Badge("cardio1", "🚴", "Ausdauer-Start", "Erste Cardio-Einheit geloggt", s.totalCardioSessions >= 1),
        Badge("km50", "🏃", "50 Kilometer", "Insgesamt 50 km Cardio", s.totalCardioKm >= 50),
        Badge("km250", "🌍", "250 Kilometer", "Insgesamt 250 km Cardio", s.totalCardioKm >= 250),
        Badge("streak2", "🔥", "Zwei Wochen am Stück", "Wochenziel 2 Wochen in Folge erreicht", s.streakWeeks >= 2),
        Badge("streak8", "🚀", "Acht Wochen am Stück", "Wochenziel 8 Wochen in Folge erreicht", s.streakWeeks >= 8),
        Badge("lvl5", "⭐", "Level 5", "Level 5 erreicht", s.level >= 5),
        Badge("lvl10", "👑", "Level 10", "Level 10 erreicht", s.level >= 10),
    )
}
