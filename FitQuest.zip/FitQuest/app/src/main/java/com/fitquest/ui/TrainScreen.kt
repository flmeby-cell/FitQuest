package com.fitquest.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.health.connect.client.PermissionController
import com.fitquest.data.CardioLog
import com.fitquest.data.Categories
import com.fitquest.data.Exercise
import com.fitquest.data.HealthConnectImporter
import com.fitquest.data.Workout
import kotlinx.coroutines.launch

@Composable
fun TrainScreen(vm: AppViewModel, onStart: (Long) -> Unit, onEdit: (Long) -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            listOf("Workouts", "Übungen", "Cardio").forEachIndexed { i, title ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
            }
        }
        when (tab) {
            0 -> WorkoutsTab(vm, onStart, onEdit)
            1 -> LibraryTab(vm)
            else -> CardioTab(vm)
        }
    }
}

// ---------------------------------------------------------------- Workouts

@Composable
private fun WorkoutsTab(vm: AppViewModel, onStart: (Long) -> Unit, onEdit: (Long) -> Unit) {
    val workouts by vm.workouts.collectAsState()
    val workoutExercises by vm.workoutExercises.collectAsState()
    val exercises by vm.exercises.collectAsState()
    var deleteTarget by remember { mutableStateOf<Workout?>(null) }

    val exById = exercises.associateBy { it.id }
    val itemsByWorkout = workoutExercises.groupBy { it.workoutId }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Button(onClick = { onEdit(-1) }, modifier = Modifier.fillMaxWidth()) { Text("+ Eigenes Workout erstellen") }
        }
        items(workouts, key = { it.id }) { workout ->
            val list = itemsByWorkout[workout.id].orEmpty()
            val muscles = list.mapNotNull { exById[it.exerciseId]?.muscleGroup }.distinct().joinToString(", ")
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(workout.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (workout.isPreset) "Vorgefertigt" else "Eigenes",
                            style = MaterialTheme.typography.labelMedium,
                        )
                    }
                    if (workout.description.isNotBlank()) {
                        Text(workout.description, style = MaterialTheme.typography.bodySmall)
                    }
                    Text("${list.size} Übungen · $muscles", style = MaterialTheme.typography.bodySmall)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(onClick = { onStart(workout.id) }, enabled = list.isNotEmpty()) { Text("Start") }
                        TextButton(onClick = { onEdit(workout.id) }) { Text("Bearbeiten") }
                        TextButton(onClick = { vm.duplicateWorkout(workout.id) }) { Text("Kopie") }
                        IconButton(onClick = { deleteTarget = workout }) { Icon(Icons.Filled.Delete, "Löschen") }
                    }
                }
            }
        }
    }

    deleteTarget?.let { w ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("„${w.name}“ löschen?") },
            text = { Text("Das Workout und seine Planeinträge werden entfernt. Geloggte Trainings bleiben erhalten.") },
            confirmButton = { TextButton(onClick = { vm.deleteWorkout(w.id); deleteTarget = null }) { Text("Löschen") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Abbrechen") } },
        )
    }
}

// ---------------------------------------------------------------- Bibliothek

@Composable
private fun LibraryTab(vm: AppViewModel) {
    val exercises by vm.exercises.collectAsState()
    var query by remember { mutableStateOf("") }
    var muscle by remember { mutableStateOf<String?>(null) }
    var equipment by remember { mutableStateOf<String?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<Exercise?>(null) }

    val filtered = exercises.filter {
        (muscle == null || it.muscleGroup == muscle) &&
            (equipment == null || it.equipment == equipment) &&
            it.name.contains(query, ignoreCase = true)
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Neue Übung speichern") }
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, label = { Text("Suchen") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                Text("Muskelgruppe", style = MaterialTheme.typography.labelMedium)
                ChipRow(Categories.muscleGroups, muscle, { muscle = it })
                Text("Trainingsmittel", style = MaterialTheme.typography.labelMedium)
                ChipRow(Categories.equipment, equipment, { equipment = it })
                Text("${filtered.size} Übungen", style = MaterialTheme.typography.labelMedium)
            }
        }
        items(filtered, key = { it.id }) { ex ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(ex.name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            "${ex.muscleGroup} · ${ex.equipment}" +
                                (if (ex.timed) " · Zeitübung" else "") +
                                (if (ex.isCustom) " · eigene" else ""),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    if (ex.isCustom) {
                        IconButton(onClick = { deleteTarget = ex }) { Icon(Icons.Filled.Delete, "Löschen") }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddExerciseDialog(
            onDismiss = { showAdd = false },
            onSave = { name, m, e, timed -> vm.addExercise(name, m, e, timed); showAdd = false },
        )
    }
    deleteTarget?.let { ex ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("„${ex.name}“ löschen?") },
            text = { Text("Die Übung wird auch aus allen Workouts entfernt.") },
            confirmButton = { TextButton(onClick = { vm.deleteExercise(ex); deleteTarget = null }) { Text("Löschen") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Abbrechen") } },
        )
    }
}

@Composable
private fun AddExerciseDialog(onDismiss: () -> Unit, onSave: (String, String, String, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var muscle by remember { mutableStateOf(Categories.muscleGroups.first()) }
    var equipment by remember { mutableStateOf(Categories.equipment.first()) }
    var timed by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Neue Übung") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Name") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                Text("Muskelgruppe", style = MaterialTheme.typography.labelMedium)
                ChipRow(Categories.muscleGroups, muscle, { it?.let { m -> muscle = m } }, allLabel = null)
                Text("Trainingsmittel", style = MaterialTheme.typography.labelMedium)
                ChipRow(Categories.equipment, equipment, { it?.let { e -> equipment = e } }, allLabel = null)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Switch(checked = timed, onCheckedChange = { timed = it })
                    Text("Zeitübung (Sekunden statt Wdh.)")
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onSave(name, muscle, equipment, timed) }) {
                Text("Speichern")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}

// ---------------------------------------------------------------- Cardio

private val cardioTypes = listOf(
    "Hometrainer (Rad)", "Laufband", "Crosstrainer", "Rudergerät",
    "Laufen", "Radfahren", "Gehen", "Sonstiges",
)

@Composable
private fun CardioTab(vm: AppViewModel) {
    val logs by vm.cardioLogs.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val importer = remember { HealthConnectImporter(context) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }

    fun runImport() {
        scope.launch {
            busy = true
            message = try {
                val n = vm.importCardio(importer.readRecent())
                if (n == 0) "Keine neuen Einheiten gefunden." else "$n neue Einheit(en) importiert."
            } catch (e: Exception) {
                "Import fehlgeschlagen: ${e.message}"
            }
            busy = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        PermissionController.createRequestPermissionResultContract(),
    ) { granted ->
        if (granted.containsAll(importer.basePermissions)) runImport()
        else message = "Berechtigung für Health Connect nicht erteilt."
    }

    fun startImport() {
        when (importer.availability()) {
            HealthConnectImporter.Availability.UNAVAILABLE ->
                message = "Health Connect ist auf diesem Gerät nicht verfügbar."

            HealthConnectImporter.Availability.UPDATE_REQUIRED ->
                message = "Bitte Health Connect im Play Store aktualisieren."

            HealthConnectImporter.Availability.AVAILABLE -> scope.launch {
                if (importer.hasBasePermissions()) runImport() else permissionLauncher.launch(importer.permissions)
            }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { showAdd = true }) { Text("Einheit loggen") }
                    OutlinedButton(onClick = { startImport() }, enabled = !busy) { Text("Aus Health Connect") }
                }
                message?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                Text(
                    "Garmin: In Garmin Connect unter Einstellungen → Health Connect die Verbindung aktivieren, " +
                        "danach hier importieren. Routen erscheinen, wenn der Zugriff erlaubt wurde.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
        items(logs, key = { it.id }) { log ->
            CardioCard(log, onDelete = { vm.deleteCardio(log.id) })
        }
    }

    if (showAdd) {
        AddCardioDialog(
            onDismiss = { showAdd = false },
            onSave = { vm.addCardio(it); showAdd = false },
        )
    }
}

@Composable
private fun CardioCard(log: CardioLog, onDelete: () -> Unit) {
    var expanded by remember(log.id) { mutableStateOf(false) }
    val route = remember(log.route) { parseRoute(log.route) }
    val speed = if (log.type.contains("Rad") && log.distanceKm > 0) {
        "%.1f km/h".format(log.distanceKm / (log.durationSec / 3600.0))
    } else fmtPace(log.durationSec, log.distanceKm)

    Card(Modifier.fillMaxWidth().clickable { expanded = !expanded }) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("${log.type} · ${fmtDay(log.date)}", style = MaterialTheme.typography.titleSmall)
            Text(
                listOfNotNull(
                    fmtDuration(log.durationSec),
                    if (log.distanceKm > 0) "%.2f km".format(log.distanceKm) else null,
                    speed,
                    if (log.kcal > 0) "${log.kcal} kcal" else null,
                ).joinToString(" · "),
                style = MaterialTheme.typography.bodyMedium,
            )
            Text("${log.source} · +${log.xp} XP", style = MaterialTheme.typography.bodySmall)
            if (expanded) {
                if (route.size >= 2) RouteMap(route) else Text("Keine Route gespeichert.", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = onDelete) { Text("Löschen") }
            }
        }
    }
}

@Composable
private fun AddCardioDialog(onDismiss: () -> Unit, onSave: (CardioLog) -> Unit) {
    var type by remember { mutableStateOf(cardioTypes.first()) }
    var day by remember { mutableLongStateOf(today()) }
    var minutes by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cardio-Einheit loggen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipRow(cardioTypes, type, { it?.let { t -> type = t } }, allLabel = null)
                DayNavigator(day) { day = it }
                NumField(minutes, { minutes = it }, "Zeit (Minuten)", Modifier.fillMaxWidth())
                NumField(km, { km = it }, "Distanz (km)", Modifier.fillMaxWidth(), decimal = true)
                NumField(kcal, { kcal = it }, "Verbrauch (kcal)", Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(
                enabled = (minutes.toIntOrNull() ?: 0) > 0,
                onClick = {
                    onSave(
                        CardioLog(
                            date = day,
                            type = type,
                            durationSec = (minutes.toIntOrNull() ?: 0) * 60,
                            distanceKm = km.toFloatLoose()?.toDouble() ?: 0.0,
                            kcal = kcal.toIntOrNull() ?: 0,
                            source = "Manuell",
                        ),
                    )
                },
            ) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}
